const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");
const fs = require("fs");
const { GoogleGenerativeAI } = require("@google/generative-ai");

const app = express();
const port = 3000;

// Middleware
app.use(cors());
app.use(bodyParser.json());

// Initialize Gemini with API key
const genAI = new GoogleGenerativeAI("YOUR_API_KEY_HERE"); // Replace with your actual Gemini API key

// Load aboutme.txt once at startup
const aboutText = fs.readFileSync("aboutme.txt", "utf8");

// /chat Route
app.post("/chat", async (req, res) => {
  const userPrompt = req.body.prompt;

  if (!userPrompt) {
    return res.status(400).json({ error: "Prompt is required" });
  }

  console.log("Received prompt:", userPrompt);

  // Gemini behavior control: always respond based ONLY on aboutText
  const fullPrompt = `
You are a chatbot trained only on the following user-provided content.

-------------------------
${aboutText}
-------------------------

Answer the user's question based only on the above content. If the answer is not found in that content, reply with:
"Sorry, that information is not available in my reference document."
Do not use any external or general knowledge.

Question: ${userPrompt}
`;

  try {
    const model = genAI.getGenerativeModel({ model: "gemini-pro" });
    const result = await model.generateContent(fullPrompt);
    const response = result.response;
    const text = response.text();

    console.log("Gemini response:", text);

    res.json({ response: text });
  } catch (error) {
    console.error("Error generating response:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

// Start server
app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
